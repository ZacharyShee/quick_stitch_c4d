"""Parametric stitch paths and surface projection for Quick Stitch.

No scene changes are made here: all output belongs to a returned cache hierarchy.
Coordinates, pitch and thread radius are expressed in the generator's local space.
"""
import math

import c4d

LEGACY, RUNNING, DOUBLE, SLANT, ZIGZAG, CHEVRON, CROSS, DIAMOND, BRAID = range(9)
STYLE_NAMES = (
    "Original / Custom", "Running", "Double Running", "Slanted",
    "Zigzag", "V / Chevron", "X / Cross", "Diamond", "Steering Wheel Braid",
)
MAX_STITCHES = 4096
MAX_POINTS = 300000
EPSILON = 1.0e-8
PERCENT_RANGES = {1107: (0.0, 1.0), 1124: (0.0, 1.0), 1125: (0.05, 0.95)}

# ID, Python type, default. Existing IDs 1000-1011 retain their meanings.
PARAMETERS = {
    "style": (1100, int, LEGACY),
    "distribution": (1101, int, 1),
    "pitch": (1102, float, 6.0),
    "seam_width": (1103, float, 6.0),
    "stitch_length": (1104, float, 3.8),
    "arch": (1105, float, 0.4),
    "cross_clearance": (1106, float, 0.15),
    "phase": (1107, float, 0.0),
    "mirror": (1108, bool, False),
    "surface": (1109, c4d.BaseList2D, None),
    "conform": (1110, bool, False),
    "surface_offset": (1111, float, 0.05),
    "ray_distance": (1112, float, 20.0),
    "up_axis": (1113, int, 0),
    "material_a": (1115, c4d.BaseList2D, None),
    "material_b": (1116, c4d.BaseList2D, None),
    "material_c": (1117, c4d.BaseList2D, None),
    "color_a": (1118, c4d.Vector, (0.15, 0.6, 1.0)),
    "color_b": (1119, c4d.Vector, (0.85, 0.035, 0.02)),
    "color_c": (1120, c4d.Vector, (0.025, 0.08, 0.22)),
    "detail": (1121, int, 8),
    "profile_steps": (1122, int, 8),
    "embed": (1123, float, 0.3),
    "roundness": (1124, float, 0.35),
    "lean": (1125, float, 0.5),
    "flip_normal": (1126, bool, False),
    "reverse": (1127, bool, False),
}


def value(op, identifier, default):
    result = op[identifier]
    return default if result is None else result


def settings(op):
    result = {}
    for name, (identifier, unused_type, default) in PARAMETERS.items():
        if isinstance(default, tuple):
            default = c4d.Vector(*default)
        result[name] = value(op, identifier, default)
    result["count"] = int(value(op, 1002, 100))
    result["radius"] = float(value(op, 1005, 0.5))
    result["rotation"] = c4d.utils.HPBToMatrix(c4d.Vector(
        value(op, 1009, 0.0), value(op, 1011, 0.0), value(op, 1010, 0.0)))
    return result


def resolved_surface(op, config):
    if not config["conform"]:
        return None
    surface = config["surface"]
    if surface is None:
        surface = op[1000]
    if surface is None:
        raise ValueError("Surface Fit needs a polygon mesh in Surface or Object.")
    if not isinstance(surface, c4d.BaseObject):
        raise ValueError("Surface must be a scene object containing a polygon mesh.")
    parent = op
    while parent is not None:
        if surface == parent:
            raise ValueError("Surface cannot be Quick Stitch or one of its parents.")
        parent = parent.GetUp()
    return surface


def dependency_signature(node):
    """Only immutable values are retained across generator evaluations."""
    if node is None:
        return None
    result = []
    pending = [node]
    while pending:
        current = pending.pop()
        matrix = current.GetMg()
        result.append((str(current.GetGUID()), current.GetDirty(
            c4d.DIRTYFLAGS_DATA | c4d.DIRTYFLAGS_MATRIX | c4d.DIRTYFLAGS_CACHE),
            tuple(component for vector in (matrix.off, matrix.v1, matrix.v2, matrix.v3)
                  for component in (vector.x, vector.y, vector.z))))
        pending.extend(current.GetChildren())
    return tuple(result)


def unit(vector, fallback=None):
    if vector.GetLengthSquared() > EPSILON:
        return vector.GetNormalized()
    return c4d.Vector(0, 1, 0) if fallback is None else c4d.Vector(fallback)


def perpendicular(normal, tangent):
    projected = normal - tangent * normal.Dot(tangent)
    if projected.GetLengthSquared() < EPSILON:
        axis = min((c4d.Vector(1, 0, 0), c4d.Vector(0, 1, 0),
                    c4d.Vector(0, 0, 1)), key=lambda v: abs(v.Dot(tangent)))
        projected = axis - tangent * axis.Dot(tangent)
    return unit(projected)


def rotate(vector, axis, angle):
    return (vector * math.cos(angle) + axis.Cross(vector) * math.sin(angle) +
            axis * axis.Dot(vector) * (1.0 - math.cos(angle)))


def transport(normal, before, after):
    axis = before.Cross(after)
    length = axis.GetLength()
    if length > EPSILON:
        normal = rotate(normal, axis / length, math.atan2(length, before.Dot(after)))
    return perpendicular(normal, after)


def _meshes(node, matrix):
    """Evaluate editable meshes, deform caches and already evaluated generators."""
    deform = node.GetDeformCache()
    cache = deform if deform is not None else node.GetCache()
    if cache is not None:
        child = cache
        while child is not None:
            yield from _meshes(child, matrix * child.GetMl())
            child = child.GetNext()
    elif isinstance(node, c4d.PolygonObject):
        yield node, matrix
    else:
        for child in node.GetChildren():
            yield from _meshes(child, matrix * child.GetMl())


class SurfaceProjector:
    def __init__(self, goal, inverse_owner, distance, flip=False):
        self.distance = distance
        self.flip = flip
        self.entries = []
        self.misses = 0
        for mesh, matrix in _meshes(goal, goal.GetMg()):
            baked = mesh.GetClone(c4d.COPYFLAGS_NO_HIERARCHY)
            transform = inverse_owner * matrix
            points = [transform * p for p in mesh.GetAllPoints()]
            baked.SetAllPoints(points)
            baked.SetMl(c4d.Matrix())
            baked.Message(c4d.MSG_UPDATE)
            collider = c4d.utils.GeRayCollider()
            if not collider.Init(baked, True):
                continue
            normals = [c4d.Vector(0) for unused in points]
            polygons = mesh.GetAllPolygons()
            for polygon in polygons:
                normal = (points[polygon.b] - points[polygon.a]).Cross(
                    points[polygon.c] - points[polygon.a])
                for index in set((polygon.a, polygon.b, polygon.c, polygon.d)):
                    normals[index] += normal
            self.entries.append((baked, collider, points, polygons, normals))
        if not self.entries:
            raise ValueError("Surface must contain an evaluated polygon mesh.")

    def _normal(self, entry, hit):
        unused_mesh, unused_collider, points, polygons, normals = entry
        polygon = polygons[hit["face_id"]]
        triangles = [(polygon.a, polygon.b, polygon.c)]
        if polygon.c != polygon.d:
            triangles.append((polygon.a, polygon.c, polygon.d))
        for a, b, c in triangles:
            e0, e1, delta = points[b] - points[a], points[c] - points[a], hit["hitpos"] - points[a]
            d00, d01, d11 = e0.Dot(e0), e0.Dot(e1), e1.Dot(e1)
            denominator = d00 * d11 - d01 * d01
            if abs(denominator) < EPSILON:
                continue
            v = (d11 * delta.Dot(e0) - d01 * delta.Dot(e1)) / denominator
            w = (d00 * delta.Dot(e1) - d01 * delta.Dot(e0)) / denominator
            u = 1.0 - v - w
            if min(u, v, w) >= -0.001:
                normal = unit(normals[a] * u + normals[b] * v + normals[c] * w)
                if normal.Dot(hit["f_normal"]) < 0:
                    normal = -normal
                return -normal if self.flip else normal
        normal = unit(hit["f_normal"])
        return -normal if self.flip else normal

    def hit(self, point, direction, search_axes=False):
        axes = [unit(direction)]
        if search_axes:
            axes.extend((c4d.Vector(1, 0, 0), c4d.Vector(0, 1, 0), c4d.Vector(0, 0, 1)))
        nearest = None
        best = self.distance * self.distance
        for axis in axes:
            for entry in self.entries:
                collider = entry[1]
                if not collider.Intersect(point + axis * self.distance, -axis,
                                          2.0 * self.distance):
                    continue
                for index in range(collider.GetIntersectionCount()):
                    hit = collider.GetIntersection(index)
                    distance = (hit["hitpos"] - point).GetLengthSquared()
                    if distance <= best:
                        best = distance
                        nearest = (hit["hitpos"], self._normal(entry, hit))
        return nearest


class PathSampler:
    def __init__(self, path, owner, config):
        # A detached clone with the generator-relative transform is our local
        # coordinate system; all spline helper results use that system.
        self.path = path.GetClone()
        self.path.SetMl(~owner.GetMg() * path.GetMg())
        self.helper = c4d.utils.SplineHelp()
        flags = c4d.SPLINEHELPFLAGS_GLOBALSPACE | c4d.SPLINEHELPFLAGS_USERDEFORMERS
        if not self.helper.InitSplineWith(self.path, flags):
            raise ValueError("Could not evaluate the path spline.")
        self.config = config

    def segment(self, index, count, projector):
        return SegmentSampler(self, index, count, projector)


class SegmentSampler:
    def __init__(self, sampler, index, count, projector):
        self.helper, self.index = sampler.helper, index
        self.config, self.projector = sampler.config, projector
        self.length = self.helper.GetSegmentLength(index)
        cache = (self.helper.GetCacheObject() if hasattr(self.helper, "GetCacheObject")
                 else sampler.path.GetRealSpline())
        if isinstance(cache, c4d.SplineObject) and cache.GetSegmentCount():
            self.closed = cache.GetSegment(index)["closed"]
        else:
            real = sampler.path.GetRealSpline()
            self.closed = bool(real and real.IsClosed())
        self.steps = min(8192, max(64, count * int(self.config["detail"])))
        axes = (c4d.Vector(0, 1, 0), c4d.Vector(0, 0, 1), c4d.Vector(1, 0, 0),
                c4d.Vector(0, -1, 0), c4d.Vector(0, 0, -1), c4d.Vector(-1, 0, 0))
        hint = axes[max(0, min(5, int(self.config["up_axis"])))]
        self.frames = []
        previous_tangent = None
        positions = [self.helper.GetPosition(i / self.steps, index, True, True)
                     for i in range(self.steps + 1)]
        for i, point in enumerate(positions):
            before = (positions[i - 1] if i else
                      positions[-2] if self.closed else positions[0])
            after = (positions[i + 1] if i < self.steps else
                     positions[1] if self.closed else positions[-1])
            # Derive the tangent from arc-length samples. Some native Python
            # builds return the normal from SplineHelp.GetTangent().
            tangent = unit(after - before, c4d.Vector(0, 0, 1))
            if previous_tangent is not None:
                hint = transport(hint, previous_tangent, tangent)
            if projector is not None:
                hit = projector.hit(point, hint, search_axes=True)
                if hit is not None:
                    point, hint = hit
                else:
                    projector.misses += 1
            normal = perpendicular(hint, tangent)
            self.frames.append((point, tangent, normal))
            hint, previous_tangent = normal, tangent
        if self.closed:
            first, last = self.frames[0], self.frames[-1]
            delta = math.atan2(first[1].Dot(last[2].Cross(first[2])),
                               last[2].Dot(first[2]))
            self.frames = [(p, t, rotate(n, t, delta * i / self.steps))
                           for i, (p, t, n) in enumerate(self.frames)]

    def position(self, distance, across, elevation):
        if self.config["reverse"]:
            distance = self.length - distance
        offset = (distance % self.length if self.closed else
                  max(0.0, min(self.length, distance))) / self.length
        scaled = offset * self.steps
        index = min(self.steps - 1, int(scaled))
        blend = scaled - index
        a, b = self.frames[index], self.frames[index + 1]
        center = a[0] * (1 - blend) + b[0] * blend
        tangent = unit(a[1] * (1 - blend) + b[1] * blend)
        normal = perpendicular(a[2] * (1 - blend) + b[2] * blend, tangent)
        side = unit(normal.Cross(tangent))
        if self.config["mirror"]:
            across = -across
        local = self.config["rotation"] * c4d.Vector(across, 0, 0)
        point = center + side * local.x + normal * local.y + tangent * local.z
        if self.projector is not None:
            hit = self.projector.hit(point, normal)
            if hit is not None:
                point, normal = hit
            else:
                self.projector.misses += 1
        lift = self.config["rotation"] * c4d.Vector(0, elevation, 0)
        return (point + normal * (self.config["radius"] + self.config["surface_offset"]) +
                side * lift.x + normal * lift.y + tangent * lift.z)


def stitch_count(length, closed, config, allocation):
    if config["distribution"] == 1:
        pitch = config["pitch"]
        if pitch <= EPSILON:
            raise ValueError("Pitch must be greater than zero.")
        count = int(round(length / pitch)) if closed else int(math.floor(length / pitch))
    else:
        count = allocation
    if closed and count and config["style"] in (ZIGZAG, DIAMOND):
        count += count % 2
    if count > MAX_STITCHES:
        raise ValueError("Too many stitches; increase Pitch or reduce Count.")
    return max(0, count)


def strokes(style, count, pitch, config, closed):
    """Return (material group, anchor vectors, closed), with X=distance, Y=width."""
    half = config["seam_width"] * 0.5
    embed = config["embed"]
    gap = 2.0 * config["radius"] + config["cross_clearance"]
    phase = (config["phase"] % 1.0) * pitch
    length = min(config["stitch_length"], pitch * 0.95)
    lean = max(0.05, min(0.95, config["lean"]))

    def p(s, x, h=-embed):
        return c4d.Vector(s + phase, x, h)

    if style in (RUNNING, DOUBLE, SLANT, CHEVRON, CROSS):
        for i in range(count):
            center = (i + 0.5) * pitch
            start, end = center - length / 2, center + length / 2
            if style in (RUNNING, DOUBLE):
                for group, lateral in ((0, 0),) if style == RUNNING else ((0, -half), (1, half)):
                    yield group, [p(start, lateral), p(end, lateral)], False
            elif style == SLANT:
                yield 0, [p(start, -half), p(start + length * lean, half)], False
            elif style == CHEVRON:
                yield 0, [p(start, -half), p(start + length * lean, 0, 0),
                          p(start, half)], False
            else:
                # Exact crossing separation is 2*radius + user clearance.
                yield 0, [p(start, -half), p(center, 0, gap), p(end, half)], False
                yield 1, [p(start, half), p(center, 0, 0), p(end, -half)], False
    elif style == ZIGZAG:
        yield 0, [p(i * pitch, half if i % 2 else -half)
                  for i in range(count + 1)], closed
    elif style == DIAMOND:
        for group in range(2):
            points = []
            for i in range(count):
                high = gap if (i + group) % 2 == 0 else 0
                points.extend((p(i * pitch, 0, high),
                               p((i + lean) * pitch, -half if group == 0 else half)))
            points.append(p(count * pitch, 0, gap if (count + group) % 2 == 0 else 0))
            yield group, points, closed
    elif style == BRAID:
        inner = half * 0.32
        for group, sign, stagger in ((0, -1, 0.0), (1, 1, lean)):
            for i in range(count):
                start = (i + stagger) * pitch
                points = [p(start, sign * inner, 0),
                          p(start + pitch * 0.25, sign * half, 0),
                          p(start + pitch * 0.70, sign * half, 0),
                          p(start + pitch, sign * inner, 0)]
                # Only the exposed pieces are modeled. Every pair has its own
                # submerged tips; no visible edge connects consecutive needles.
                for a, b in zip(points, points[1:]):
                    yield group, [a, b], False
        for i in range(count):
            points = [p(i * pitch, -inner, 0),
                      p((i + lean) * pitch, inner, 0),
                      p((i + 1) * pitch, -inner, 0)]
            for a, b in zip(points, points[1:]):
                yield 2, [a, b], False


def sampling_detail(config):
    return max(12 if config["style"] == BRAID else 2,
               min(48, int(config["detail"])))


def sample_needle(anchors, sampler, config):
    """A single visible needle arc, with both complete tube tips below skin."""
    a, b = anchors
    if not sampler.closed:
        delta = b.x - a.x
        if abs(delta) < EPSILON:
            if not 0 <= a.x <= sampler.length:
                return []
        else:
            limits = sorted(((0 - a.x) / delta, (sampler.length - a.x) / delta))
            start, end = max(0.0, limits[0]), min(1.0, limits[1])
            if end - start <= EPSILON:
                return []
            direction = b - a
            b = a + direction * end
            a = a + direction * start
    if (b - a).GetLengthSquared() <= EPSILON:
        return []
    detail = sampling_detail(config)
    rounding = max(0.0, min(1.0, config["roundness"]))
    # position() adds radius + clearance. Subtract another radius at the tips
    # so the entire tube cap, rather than only its center, is buried.
    penetration = 2.0 * config["radius"] + config["surface_offset"] + config["embed"]
    points = []
    for i in range(detail + 1):
        t = i / detail
        q = a * (1 - t) + b * t
        profile = ((1 - rounding) * (1 - (2*t - 1)**4) +
                   rounding * math.sin(math.pi * t))
        elevation = -penetration + (penetration + config["arch"]) * profile
        points.append(sampler.position(q.x, q.y, elevation))
    return [(points, False)]


def sample_stroke(anchors, closed, sampler, config):
    if config["style"] == BRAID:
        return sample_needle(anchors, sampler, config)
    detail = sampling_detail(config)
    rounding = max(0.0, min(1.0, config["roundness"]))
    # Closed anchors include the repeated first anchor one period later.
    chunks, points = [], []
    for i in range(len(anchors) - 1):
        a, b = anchors[i], anchors[i + 1]
        before = anchors[i - 1] if i else a - (b - a)
        after = anchors[i + 2] if i + 2 < len(anchors) else b + (b - a)
        if closed:
            period = anchors[-1].x - anchors[0].x
            if i == 0:
                before = c4d.Vector(anchors[-2])
                before.x -= period
            if i + 2 == len(anchors):
                after = c4d.Vector(anchors[1])
                after.x += period
        for j in range(detail):
            t = j / detail
            if rounding:
                t2, t3 = t * t, t * t * t
                q = (a * (2*t3 - 3*t2 + 1) + b * (-2*t3 + 3*t2) +
                     (b - before) * (0.5 * rounding * (t3 - 2*t2 + t)) +
                     (after - a) * (0.5 * rounding * (t3 - t2)))
            else:
                q = a * (1 - t) + b * t
            q.z += config["arch"] * math.sin(math.pi * t) ** 2
            if not sampler.closed and not -EPSILON <= q.x <= sampler.length + EPSILON:
                if len(points) >= 2:
                    chunks.append((points, False))
                points = []
                continue
            points.append(sampler.position(q.x, q.y, q.z))
    end = anchors[-1]
    if not closed and (sampler.closed or 0 <= end.x <= sampler.length):
        points.append(sampler.position(end.x, end.y, end.z))
    if len(points) >= 2:
        chunks.append((points, closed))
    return chunks


def make_sweep(group, strands, config):
    total = sum(len(points) for points, unused in strands)
    path = c4d.SplineObject(total, c4d.SPLINETYPE_LINEAR)
    if not path.ResizeObject(total, len(strands)):
        raise MemoryError("Could not allocate thread paths.")
    points = []
    for index, (strand, closed) in enumerate(strands):
        path.SetSegment(index, len(strand), closed)
        points.extend(strand)
    path.SetAllPoints(points)
    path[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_NONE
    path.SetName("Thread Paths " + "ABC"[group])
    path.Message(c4d.MSG_UPDATE)
    profile = c4d.BaseObject(c4d.Osplinecircle)
    profile[c4d.PRIM_CIRCLE_RADIUS] = config["radius"]
    profile[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_UNIFORM
    profile[c4d.SPLINEOBJECT_SUB] = max(3, min(32, int(config["profile_steps"])))
    sweep = c4d.BaseObject(c4d.Osweep)
    sweep.SetName(("Left / Thread A", "Right / Thread B", "Lacing / Thread C")[group])
    path.InsertUnder(sweep)
    profile.InsertUnder(sweep)
    sweep.SetPhong(True, True, c4d.utils.DegToRad(60))
    sweep[c4d.ID_BASEOBJECT_USECOLOR] = c4d.ID_BASEOBJECT_USECOLOR_ALWAYS
    sweep[c4d.ID_BASEOBJECT_COLOR] = config["color_" + "abc"[group]]
    material = config["material_" + "abc"[group]]
    if material is not None:
        if not isinstance(material, c4d.BaseMaterial):
            raise ValueError("Thread material slots accept materials only.")
        tag = c4d.TextureTag()
        tag.SetMaterial(material)
        tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_UVW
        sweep.InsertTag(tag)
    return sweep


def build(owner, path, config, surface=None):
    root = c4d.BaseObject(c4d.Onull)
    root.SetName(STYLE_NAMES[config["style"]])
    if config["radius"] <= 0 or config["seam_width"] < 0 or config["stitch_length"] <= 0:
        return root
    if config["distribution"] == 0 and config["count"] <= 0:
        return root
    if config["distribution"] == 0 and config["count"] > MAX_STITCHES:
        raise ValueError("Too many stitches; reduce Count.")
    if config["distribution"] == 1 and config["pitch"] <= EPSILON:
        raise ValueError("Pitch must be greater than zero.")
    if config["ray_distance"] <= EPSILON and surface is not None:
        raise ValueError("Projection Distance must be greater than zero.")
    sampler = PathSampler(path, owner, config)
    lengths = [sampler.helper.GetSegmentLength(i)
               for i in range(sampler.helper.GetSegmentCount())]
    total_length = sum(lengths)
    if total_length <= EPSILON:
        return root
    counts = [int(config["count"] * length / total_length) for length in lengths]
    if config["distribution"] == 0:
        remainder = config["count"] - sum(counts)
        order = sorted(range(len(lengths)), key=lambda i:
                       config["count"] * lengths[i] / total_length - counts[i], reverse=True)
        for i in order[:remainder]:
            counts[i] += 1
    projector = SurfaceProjector(surface, ~owner.GetMg(), config["ray_distance"],
                                 config["flip_normal"]) if surface is not None else None
    groups = [[], [], []]
    point_total = 0
    cell_total = 0
    for index, length in enumerate(lengths):
        if length <= EPSILON:
            continue
        estimate = (int(math.ceil(length / config["pitch"]))
                    if config["distribution"] == 1 else counts[index])
        if estimate > MAX_STITCHES:
            raise ValueError("Too many stitches; increase Pitch or reduce Count.")
        segment = sampler.segment(index, max(1, estimate), projector)
        count = stitch_count(length, segment.closed, config, counts[index])
        cell_total += count
        if cell_total > MAX_STITCHES:
            raise ValueError("Too many stitches across path segments.")
        if not count:
            continue
        pitch = length / count if segment.closed or config["distribution"] == 0 else config["pitch"]
        for group, anchors, closed in strokes(config["style"], count, pitch, config, segment.closed):
            estimate = (len(anchors) - 1) * sampling_detail(config) + 1
            if point_total + estimate > MAX_POINTS:
                raise ValueError("Thread detail is too high; reduce Detail or stitch count.")
            chunks = sample_stroke(anchors, closed, segment, config)
            point_total += sum(len(points) for points, unused in chunks)
            if point_total > MAX_POINTS:
                raise ValueError("Thread detail is too high; reduce Detail or stitch count.")
            groups[group].extend(chunks)
    if projector is not None and projector.misses:
        raise ValueError("Surface projection missed {} samples. Increase Projection Distance, "
                         "choose a closer path, or disable Surface Fit.".format(projector.misses))
    for group in reversed(range(3)):
        if groups[group]:
            make_sweep(group, groups[group], config).InsertUnder(root)
    return root
