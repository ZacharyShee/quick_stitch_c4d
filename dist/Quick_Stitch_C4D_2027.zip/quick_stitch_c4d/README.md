# Quick Stitch

Original custom stitches plus eight parametric patterns for Cinema 4D 2027.
See [使用说明](使用说明.md) for the Chinese installation and parameter guide.

![Pattern atlas](examples/stitch_styles.png)

A free plugin for Cinema4D to easily and quickly create stitches.

![Comp 1 (0-00-00-02)](https://user-images.githubusercontent.com/30839669/78103828-d1776c80-7428-11ea-96f9-fd645d59bc28.png)

# Installing

Put this folder, including **`quick_stitch.pyp`, `quick_stitch_patterns.py`, and `res`**, in C4D's plugin folder,
then restart Cinema 4D. Keep only one installed Quick Stitch version: the plugin
ID remains `1054816` so existing scenes retain their object type. Another `.pyp`
or encrypted `.pypv` version using that ID must be moved out of the plugin search
paths before installing this version.

`quick_stitch_original_py2.pyp.bak` preserves the original source for reference.
Keep the `.bak` suffix so Cinema 4D does not execute it as a second plugin.

# Usage

Youtube Link:
https://youtu.be/tS6OjRC7nik

1. Create a QuickStitch object and link an editable polygon mesh in **Object**.
2. Select edges on that mesh, then click **Make Stitch**. A path spline is created
   under QuickStitch. Creating or replacing the path supports Undo and Redo.
3. Choose **Stitch Style**. Original / Custom retains the old Shape controls.
   New styles include running, double running, slanted, zigzag, V, X, diamond,
   and three-thread steering-wheel braid.
4. New patterns default to **By Pitch**. Switch to By Count to use Count instead.
   Adjust seam width, length, arch, entry depth, crossing clearance, stagger,
   mirroring, reverse direction and quality. Thickness is the thread radius.
5. Enable **Surface Fit** and link an evaluated polygon surface, or leave Surface
   empty to use Object. Choose an up axis for paths without a fitting surface.
6. Assign thread materials in A/B/C. Preview colors affect the editor only.
   Use the same material in multiple slots for single-color stitching.

An editable or primitive spline can also be placed directly under QuickStitch.
The first direct spline child is the path; unrelated children are skipped and
preserved. Changes to that path invalidate the generated cache. Edge extraction
is a snapshot: click **Make Stitch** again after changing the source mesh or its
edge selection. Invalid button input is reported in the status bar and console.

# Compatibility fixes

- Accept both the older Init call and the clone-initialization argument added
  in Cinema 4D 2024; preserve copied parameters during clone initialization.
- Convert selected edges on a temporary mesh copy with an explicit modeling
  container. Parent the new path before setting its world matrix.
- Read the current Object link at button-click time. Validate the mesh and edge
  selection before changing an existing path or opening an undo operation.
- Build generated objects locally and keep their path link inside the returned
  hierarchy, avoiding persistent references to another object's cache or path.
- Track spline geometry, transform, and cache changes. Return an empty Null for
  missing input instead of repeatedly requesting an invalid cache.
- Fall back to the default icon and log a warning when the bitmap cannot load.

# Regression checks

Run `tests/c4d_patterns.py` (includes the legacy suite) from Cinema 4D's Script Manager, or execute it with
C4D's embedded Python. The checks use detached temporary documents and do not
register a plugin, replace an installed version, or edit the active scene.

The runner reads parameter IDs from this project's header. Most checks use a
disabled native Python Generator as a parameter host and exercise the workspace
source directly, including real edge conversion, world transforms, Undo/Redo,
copied paths, and native Sweep/Cloner evaluation. Direct calls force cache
rebuilding because they do not supply the internal hierarchy-help capsule.

An additional enabled Python Generator calls the same implementation with a real
native hierarchy-help capsule and matching cache settings. It checks updates
after parameter and spline-point changes, including subsequent clean evaluations.
Installing the plugin and restarting C4D is still needed to verify plugin startup
and actual ObjectData registration for a particular C4D release.

# Pattern details

Closed paths fit the repeat interval to their length. Closed zigzag, diamond and
braid patterns use even repeat counts to preserve the alternating join. Count is
distributed across disconnected path segments; open paths keep the requested pitch.
Surface projection failures return empty output and a console message rather than
partial floating threads. New patterns are limited to 4096 repeats and 300000 path
samples; reduce detail/count or increase pitch for larger scenes.

`examples/Quick_Stitch_Styles.c4d` is a portable native geometry snapshot with the
eight patterns, a fitted cylinder, and a fitted steering-wheel torus. It contains
native sweeps and paths rather than a live custom plugin object. The PNG atlas is
an orthographic drawing of the generated curves, not a leather material render.

The new styles model visible thread paths. Needle holes, leather dents and cloth
simulation are outside this version. Original code and attribution remain in the
source header, with the untouched Python 2 source preserved in the .bak file.
